
-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `userid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `sub_code` int(11) NOT NULL,
  `obt_marks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
