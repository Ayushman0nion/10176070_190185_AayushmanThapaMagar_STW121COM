
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `faculty` varchar(7) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `name`, `faculty`, `username`, `password`) VALUES
(1, 'student test', 'student', 'stest', 'test'),
(2, 'teacher test', 'teacher', 'ttest', 'test'),
(3, 'atm', 'student', 'atest', 'test');
